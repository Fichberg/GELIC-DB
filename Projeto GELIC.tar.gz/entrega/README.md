# GELIC-DB
Um projeto de banco de dados para IME-USP MAC0439 - Curso de Laboratório de Banco de Dados.

## Integrantes do Grupo

- Monica Vani Vieira Lopes da Silva n° 5998865
- Renan Fichberg n°7991131
- Vinícius Nascimento Silva nº 7557626
